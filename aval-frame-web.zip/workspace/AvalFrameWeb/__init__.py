"""
Package for AvalFrameWeb.
"""
