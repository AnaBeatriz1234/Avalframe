"""
Definition of urls for AvalFrameWeb.
"""

from datetime import datetime
from django.conf.urls import url
from django.conf.urls import include
import django.contrib.auth.views

import app.forms
import app.views
from app.views import unidades_medida

# Uncomment the next lines to enable the admin:
# from django.conf.urls import include
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = [
    url(r'^$', unidades_medida.index.as_view(), name='unidades_medida_index'),
    url(r'^novo_alterar/$', unidades_medida.novo_alterar.as_view(), name='unidades_medida_novo'),
    url(r'^novo_alterar/(?P<codigo>\d+)$', unidades_medida.novo_alterar.as_view(), name='unidades_medida_alterar'),
    url(r'^deletar/(?P<codigo>\d+)$', unidades_medida.deletar.as_view(), name='unidades_medida_deletar'),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
]
