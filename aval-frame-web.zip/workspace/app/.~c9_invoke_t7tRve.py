"""
Definition of forms.
"""

from django import forms
from django.forms import ModelForm
from app.models import *
from django.contrib.auth.forms import AuthenticationForm
from django.utils.translation import ugettext_lazy as _

class BootstrapAuthenticationForm(AuthenticationForm):
    """Authentication form which uses boostrap CSS."""
    username = forms.CharField(max_length=254,
                               widget=forms.TextInput({
                                   'class': 'form-control',
                                   'placeholder': 'User name'}))
    password = forms.CharField(label=_("Password"),
                               widget=forms.PasswordInput({
                                   'class': 'form-control',
                                   'placeholder':'Password'}))

class Competencias_Form(ModelForm):
    class Meta:
        model = Competencias
        fields = ['codigo', 'titulo', 'valor_maximo_pontos']

class NiveisDeCompetenciaAvaliacao_Form(ModelForm):
    class Meta:
        model = NiveisDeCompetenciaAvaliacao
        fields = ['codigo', 'codigo_competencia', 'titulo', 'inicio_nivel', 'fim_nivel', 'jogadores_nesse_nivel']

class Aprendizagens_Form(ModelForm):
    class Meta:
        model = Aprendizagens
        fields = ['codigo', 'tipo', 'titulo']

class NiveisDeApredizagem_Form(ModelForm):
    class Meta:
        model = NiveisDeApredizagem
        fields = ['codigo', 'codigo_apredizagem', 'titulo', 'inicio_nivel', 'fim_nivel', 'jogadores_nesse_nivel']
        
class JogosDigitais_Form(ModelForm):
    class Meta:
        model = JogosDigitais
        fields = ['codigo', 'titulo']
        
class NiveisJogo_Form(ModelForm):
    class Meta:
        model = NiveisJogo
        fields = ['codigo', 'codigo_jogo', 'titulo']
        
class Aeej_Form(ModelForm):
    class Meta:
        model = Aeej
        fields = ['codigo', 'codigo_jogo', 'tipo', 'descricao']
        
class DispositivosCaptura_Form(ModelForm):
    class Meta:
        model = DispositivosCaptura
        fields = ['codigo', 'tipo', 'nome']
        
class DadosMultimodais_Form(ModelForm):
    class Meta:
        model = DadosMultimodais
        fields = ['codigo', 'codigo_dispositivo', 'nome', 'codigo_unidade_medida']
        
class UnidadesMedida_Form(ModelForm):
    class Meta:
        model = UnidadesMedida
        fields = ['codigo', 'nome']
        
class UnidadesMedida_Form(ModelForm):
    class Meta:
        model = UnidadesMedida
        fields = ['codigo', 'nome']
        
