"""
Definition of forms.
"""

from django import forms
from django.forms import ModelForm
from app.models import *
from django.contrib.auth.forms import AuthenticationForm
from django.utils.translation import ugettext_lazy as _

class Aeej_Form(ModelForm):
    class Meta:
        model = Aeej
        fields = ['codigo_jogo', 'tipo', 'descricao']
        
class Aprendizagens_Form(ModelForm):
    class Meta:
        model = Aprendizagens
        fields = ['tipo', 'titulo']

class BootstrapAuthenticationForm(AuthenticationForm):
    """Authentication form which uses boostrap CSS."""
    username = forms.CharField(max_length=254,
                               widget=forms.TextInput({
                                   'class': 'form-control',
                                   'placeholder': 'User name'}))
    password = forms.CharField(label=_("Password"),
                               widget=forms.PasswordInput({
                                   'class': 'form-control',
                                   'placeholder':'Password'}))

class Competencias_Form(ModelForm):
    class Meta:
        model = Competencias
        fields = ['titulo', 'valor_maximo_pontos']

class NiveisCompetenciaAvaliacao_Form(ModelForm):
    class Meta:
        model = NiveisCompetenciaAvaliacao
        fields = ['codigo_competencia', 'titulo', 'inicio_nivel', 'fim_nivel', 'jogadores_nesse_nivel']

class NiveisAprendizagem_Form(ModelForm):
    class Meta:
        model = NiveisAprendizagem
        fields = ['codigo_apredizagem', 'titulo', 'inicio_nivel', 'fim_nivel', 'jogadores_nesse_nivel']
        
class NiveisJogo_Form(ModelForm):
    class Meta:
        model = NiveisJogo
        fields = ['codigo_jogo', 'titulo', 'nivel']
        
class DispositivosCaptura_Form(ModelForm):
    class Meta:
        model = DispositivosCaptura
        fields = ['tipo', 'nome']
        
class DadosMultimodais_Form(ModelForm):
    class Meta:
        model = DadosMultimodais
        fields = ['codigo_dispositivo', 'nome', 'codigo_unidade_medida']
        
class JogosDigitais_Form(ModelForm):
    class Meta:
        model = JogosDigitais
        fields = ['titulo']
        
class UnidadesMedida_Form(ModelForm):
    class Meta:
        model = UnidadesMedida
        fields = ['nome']
        
class Jogadores_Form(ModelForm):
    class Meta:
        model = Jogadores
        fields = ['nome', 'sexo', 'data_nascimento', 'data_desde_quando_joga']
        
